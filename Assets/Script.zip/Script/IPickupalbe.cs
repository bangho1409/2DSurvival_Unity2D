using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This Script Used for GameObject that be able to Obtain like Coins, Experiences.

public interface IPickupalbe
{
    void PickUp(Character character);
}
